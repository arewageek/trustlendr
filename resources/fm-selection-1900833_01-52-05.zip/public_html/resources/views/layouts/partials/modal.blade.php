<div class="modal w-screen h-screen top-0 left-0 right-0 fixed backdrop-blur-md bg-[#0005] text-white">
 COntent
</div>